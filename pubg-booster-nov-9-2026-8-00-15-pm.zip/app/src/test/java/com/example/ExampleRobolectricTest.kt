package com.example

import com.example.model.HardwareStatus
import com.example.model.ThreatLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

  @Test
  fun testHardwareStatusDefaults() {
    val status = HardwareStatus()
    assertEquals(80, status.cpuCapPercent)
    assertTrue(status.isCapEnabled)
    assertEquals("schedutil", status.activeGovernor)
  }

  @Test
  fun testThreatLevelEnum() {
    val threats = ThreatLevel.values()
    assertTrue(threats.contains(ThreatLevel.HIGH_RISK_TROJAN))
  }
}
