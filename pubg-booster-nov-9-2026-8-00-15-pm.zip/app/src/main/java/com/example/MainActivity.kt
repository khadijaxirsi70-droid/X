package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.DragonHeader
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.BoosterViewModel

enum class BoosterTab(val label: String, val icon: ImageVector) {
    LIFESPAN("العتاد 8Y", Icons.Default.Shield),
    SYSTEM("النظام", Icons.Default.Memory),
    NETWORK("الشبكة 25ms", Icons.Default.Wifi),
    SECURITY("الأمان", Icons.Default.Security),
    GAMER("الألعاب", Icons.Default.SportsEsports),
    OVERLORD("السيطرة", Icons.Default.Bolt)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppContent()
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: BoosterViewModel = viewModel()) {
    val hardwareStatus by viewModel.hardwareStatus.collectAsStateWithLifecycle()
    val systemState by viewModel.systemState.collectAsStateWithLifecycle()
    val networkState by viewModel.networkState.collectAsStateWithLifecycle()
    val securityThreats by viewModel.securityThreats.collectAsStateWithLifecycle()
    val isScanningSecurity by viewModel.isScanningSecurity.collectAsStateWithLifecycle()
    val crosshairConfig by viewModel.crosshairConfig.collectAsStateWithLifecycle()
    val hudConfig by viewModel.hudConfig.collectAsStateWithLifecycle()
    val eyeFilterActive by viewModel.eyeFilterActive.collectAsStateWithLifecycle()
    val isWatchdogActive by viewModel.isWatchdogActive.collectAsStateWithLifecycle()
    val isGhostModeActive by viewModel.isGhostModeActive.collectAsStateWithLifecycle()

    val zonePhase by viewModel.zonePhase.collectAsStateWithLifecycle()
    val zoneTimeSeconds by viewModel.zoneTimeSeconds.collectAsStateWithLifecycle()
    val isZoneTimerRunning by viewModel.isZoneTimerRunning.collectAsStateWithLifecycle()
    val sensitivities by viewModel.sensitivityValues.collectAsStateWithLifecycle()
    val audioPreset by viewModel.audio3dPreset.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableStateOf(BoosterTab.LIFESPAN) }

    // Request permissions for notifications & audio if on Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    LaunchedEffect(Unit) {
        val permissionsToRequest = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        permissionLauncher.launch(permissionsToRequest.toTypedArray())
    }

    // Ghost Mode check
    if (isGhostModeActive) {
        BackHandler {
            viewModel.toggleGhostMode()
        }
        GhostCalculatorScreen(
            onUnlock = { viewModel.toggleGhostMode() }
        )
        return
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("pubg_booster_scaffold"),
        containerColor = CosmicDark,
        bottomBar = {
            NavigationBar(
                containerColor = CosmicSurface,
                tonalElevation = 8.dp
            ) {
                BoosterTab.values().forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                tint = if (isSelected) NeonCyan else TextSecondary
                            )
                        },
                        label = {
                            Text(
                                text = tab.label,
                                color = if (isSelected) NeonCyan else TextSecondary,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color(0x3300F0FF)
                        ),
                        modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Cosmic Dragon Banner Header with Developer Credentials & Telemetry
            DragonHeader(
                fps = if (systemState.refreshRateLocked60Hz) 60 else 30,
                pingMs = networkState.pingMs,
                batteryTempC = hardwareStatus.batteryTempC,
                cpuCapPercent = hardwareStatus.cpuCapPercent,
                onPanicReset = { viewModel.panicReset() }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Main Active Tab Content
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    BoosterTab.LIFESPAN -> {
                        HardwareLifespanScreen(
                            status = hardwareStatus,
                            onToggleCap = { viewModel.toggleCpuCap() },
                            onSetCap = { viewModel.setCpuCap(it) },
                            onApplyCoreAffinity = { viewModel.applyCoreAffinity() }
                        )
                    }
                    BoosterTab.SYSTEM -> {
                        AtomicSystemScreen(
                            state = systemState,
                            onProtectOom = { viewModel.applyOomProtection() },
                            onApplyIoBooster = { viewModel.applyIoBooster() },
                            onLockRefreshRate = { viewModel.lockRefreshRate60Hz() },
                            onToggleResolution = { viewModel.toggleResolution720p() }
                        )
                    }
                    BoosterTab.NETWORK -> {
                        QuantumNetworkScreen(
                            state = networkState,
                            onRunBenchmark = { viewModel.runDnsBenchmark() },
                            onToggleWifiLock = { viewModel.toggleWifiLock() },
                            onToggleKillSwitch = { viewModel.toggleKillSwitch() }
                        )
                    }
                    BoosterTab.SECURITY -> {
                        AntiMalwareScreen(
                            threats = securityThreats,
                            isScanning = isScanningSecurity,
                            onRescan = { viewModel.runSecurityScan() }
                        )
                    }
                    BoosterTab.GAMER -> {
                        GamerEdgeScreen(
                            sensitivities = sensitivities,
                            onCalculateSensitivity = { size, hz, gyro ->
                                viewModel.calculateSensitivity(size, hz, gyro)
                            },
                            zonePhase = zonePhase,
                            zoneTimeSeconds = zoneTimeSeconds,
                            isZoneTimerRunning = isZoneTimerRunning,
                            onToggleZoneTimer = { viewModel.toggleZoneTimer() },
                            onAdvanceZonePhase = { viewModel.advanceZonePhase() },
                            onResetZoneTimer = { viewModel.resetZoneTimer() },
                            audioPreset = audioPreset,
                            onSelectAudioPreset = { viewModel.setAudio3dPreset(it) },
                            eyeFilterActive = eyeFilterActive,
                            onToggleEyeFilter = { viewModel.toggleEyeFilter(it) },
                            crosshairConfig = crosshairConfig,
                            onToggleCrosshair = { enabled, style, color ->
                                viewModel.toggleCrosshair(enabled, style, color)
                            }
                        )
                    }
                    BoosterTab.OVERLORD -> {
                        SystemOverlordScreen(
                            hudConfig = hudConfig,
                            onToggleHud = { viewModel.toggleFloatingHud(it) },
                            isWatchdogActive = isWatchdogActive,
                            onToggleWatchdog = { viewModel.toggleWatchdog(it) },
                            isGhostMode = isGhostModeActive,
                            onToggleGhostMode = { viewModel.toggleGhostMode() },
                            onPanicReset = { viewModel.panicReset() }
                        )
                    }
                }
            }
        }
    }
}
