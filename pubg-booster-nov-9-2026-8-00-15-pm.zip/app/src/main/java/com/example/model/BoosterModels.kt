package com.example.model

data class CoreInfo(
    val id: Int,
    val type: String, // "Big Core" or "Little Core"
    val isAssignedToGame: Boolean,
    val currentFreqMhz: Int,
    val usagePercent: Int
)

data class HardwareStatus(
    val cpuCapPercent: Int = 80,
    val isCapEnabled: Boolean = true,
    val currentCpuMhz: Int = 1800,
    val maxCpuMhz: Int = 2200,
    val activeGovernor: String = "schedutil",
    val cores: List<CoreInfo> = emptyList(),
    val batteryTempC: Float = 34.5f,
    val batteryLevel: Int = 78,
    val batteryVoltageMv: Int = 3980,
    val isStopChargeAt80Enabled: Boolean = true,
    val isBypassChargingActive: Boolean = false,
    val isPredictiveCoolingActive: Boolean = false,
    val thermalWarningTriggered: Boolean = false
)

data class SystemControlState(
    val oomAdjProtected: Boolean = true,
    val oomScore: Int = -17,
    val ioBoosterActive: Boolean = true,
    val ioPriorityClass: String = "Real-time (RT class 1)",
    val refreshRateLocked60Hz: Boolean = true,
    val currentRefreshRate: Float = 60.0f,
    val resolutionMode: String = "720p (Ultra Stable 60FPS)",
    val isShizukuAvailable: Boolean = false,
    val lastExecutedCommand: String = ""
)

data class DnsBenchmark(
    val name: String,
    val primaryIp: String,
    val secondaryIp: String,
    val latencyMs: Long = -1L,
    val isTesting: Boolean = false,
    val isBest: Boolean = false
)

data class NetworkState(
    val pingMs: Int = 26,
    val jitterMs: Int = 2,
    val packetLossPercent: Float = 0.0f,
    val isWifiLockActive: Boolean = true,
    val isKillSwitchActive: Boolean = false,
    val activeDns: String = "Cloudflare 1.1.1.1 Gaming Route",
    val benchmarks: List<DnsBenchmark> = emptyList(),
    val routeStabilityScore: Int = 99
)

enum class ThreatLevel {
    SAFE,
    SUSPICIOUS,
    HIGH_RISK_TROJAN
}

data class AppSecurityThreat(
    val packageName: String,
    val appName: String,
    val threatLevel: ThreatLevel,
    val riskReasons: List<String>,
    val dangerousPermissions: List<String>,
    val sha256Hash: String = ""
)

enum class CrosshairStyle {
    NEON_DOT,
    CYBER_CROSS,
    CIRCLE_DOT,
    DRAGON_EYE
}

data class CrosshairConfig(
    val isEnabled: Boolean = false,
    val style: CrosshairStyle = CrosshairStyle.NEON_DOT,
    val colorHex: String = "#00F0FF",
    val sizeDp: Int = 28,
    val alpha: Float = 0.95f
)

data class HudOverlayConfig(
    val isEnabled: Boolean = false,
    val showFps: Boolean = true,
    val showPing: Boolean = true,
    val showTemp: Boolean = true,
    val simulatedFps: Int = 60
)

data class ZonePhase(
    val phaseNumber: Int,
    val waitSeconds: Int,
    val shrinkSeconds: Int,
    val damageDps: Float
)
