package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun GhostCalculatorScreen(
    onUnlock: () -> Unit,
    modifier: Modifier = Modifier
) {
    var displayValue by remember { mutableStateOf("0") }

    fun onKeyClick(key: String) {
        when (key) {
            "C" -> displayValue = "0"
            "=" -> {
                if (displayValue == "7777") {
                    onUnlock()
                } else {
                    displayValue = try {
                        val num = displayValue.toDoubleOrNull() ?: 0.0
                        "%.2f".format(num)
                    } catch (e: Exception) {
                        "Error"
                    }
                }
            }
            else -> {
                displayValue = if (displayValue == "0") key else displayValue + key
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CosmicDark)
            .padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Disguised Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Calculator",
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "System Calculator Pro", color = TextSecondary, fontSize = 12.sp)
            }

            // Secret Tap Button to unlock
            IconButton(onClick = onUnlock) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Secret Unlock",
                    tint = Color(0x3300F0FF)
                )
            }
        }

        // Display Screen
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CosmicSurfaceVariant)
                .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                .padding(24.dp),
            contentAlignment = Alignment.BottomEnd
        ) {
            Text(
                text = displayValue,
                color = NeonCyan,
                fontSize = 42.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        // Keypad Grid
        val keys = listOf(
            listOf("C", "±", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "DEL", "=")
        )

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            keys.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    row.forEach { k ->
                        val isOp = k in listOf("÷", "×", "-", "+", "=")
                        val isSpecial = k in listOf("C", "±", "%")

                        val btnColor = when {
                            k == "=" -> NeonCyan
                            isOp -> NeonBlue
                            isSpecial -> CosmicSurfaceVariant
                            else -> Color(0xFF131D33)
                        }

                        val textColor = when {
                            k == "=" -> Color(0xFF030712)
                            isOp -> Color.White
                            else -> TextPrimary
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1.1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(btnColor)
                                .clickable {
                                    if (k == "DEL") {
                                        displayValue = if (displayValue.length > 1) displayValue.dropLast(1) else "0"
                                    } else {
                                        onKeyClick(k)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = k,
                                color = textColor,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Text(
            text = "Enter passcode [ 7777= ] or tap shield to reveal Absolute Protocol",
            color = Color(0x668B949E),
            fontSize = 10.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}
