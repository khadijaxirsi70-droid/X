package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SystemControlState
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonButton
import com.example.ui.components.PulsingStatusDot
import com.example.ui.theme.*

@Composable
fun AtomicSystemScreen(
    state: SystemControlState,
    onProtectOom: () -> Unit,
    onApplyIoBooster: () -> Unit,
    onLockRefreshRate: () -> Unit,
    onToggleResolution: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp)
    ) {
        // Module Title
        item {
            GlassCard(borderColor = NeonCyan, backgroundColor = Color(0xCC071120)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = "System Control",
                        tint = NeonCyan,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "الموديول 2: السيطرة على النظام ومحو العيوب (Atomic Control)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "منع الخروج المفاجئ (Anti-Crash)، تحرير الذاكرة، وتثبيت 60 إطاراً",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // 1. Process Protector (oom_score_adj = -17)
        item {
            GlassCard(borderColor = if (state.oomAdjProtected) NeonGreen else NeonCyan) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "1. حامي اللعبة (Process Protector)",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            if (state.oomAdjProtected) PulsingStatusDot(color = NeonGreen)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "تعديل oom_score_adj لعملية ببجي إلى -17 (أعلى أولوية حصانة). يمنع مقتل اللعبة أثناء الفايت.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    NeonButton(
                        text = if (state.oomAdjProtected) "محصن (-17)" else "تفعيل الحصانة",
                        onClick = onProtectOom,
                        color = NeonGreen,
                        modifier = Modifier.height(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF020617))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "TARGET: com.tencent.ig | OOM_SCORE_ADJ: -17 | IMMUNITY: MAXIMUM",
                        fontFamily = FontFamily.Monospace,
                        color = NeonCyan,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // 2. I/O Booster (ionice)
        item {
            GlassCard(borderColor = NeonBlue) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "2. مضخم التخزين (I/O Booster)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "استخدام ionice -c 1 -n 0 لرفع أولوية قراءة السكنات والخرائط ومنع تجمد الشاشة (Freezes).",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    NeonButton(
                        text = "تضخيم I/O",
                        onClick = onApplyIoBooster,
                        color = NeonBlue,
                        modifier = Modifier.height(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "الحالة الحالية: ${state.ioPriorityClass}",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // 3. 60Hz Refresh Rate Locker
        item {
            GlassCard(borderColor = NeonYellow) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "3. مثبت التردد (60Hz Anti-Throttle)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "إجبار الشاشة على 60Hz ومنع هبوطها إلى 30Hz لتفادي البطء أثناء الاشتباكات المزدحمة.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    NeonButton(
                        text = "قفل 60Hz",
                        onClick = onLockRefreshRate,
                        color = NeonYellow,
                        modifier = Modifier.height(36.dp)
                    )
                }
            }
        }

        // 4. Dynamic 720p Resolution Scaler
        item {
            GlassCard(borderColor = NeonPurple) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "4. خافض الدقة الديناميكي (720p Dynamic Scaler)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ضبط دقة العرض إلى 720p لتخفيف الحمل الرسومي على معالج AirTab التابلت وتثبيت 60fps مستقر كلياً.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    NeonButton(
                        text = if (state.resolutionMode.contains("720p")) "720p نشط" else "تفعيل 720p",
                        onClick = onToggleResolution,
                        color = NeonPurple,
                        modifier = Modifier.height(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "الوضع الرسومي الحالي: ${state.resolutionMode}",
                    color = NeonGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
