package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HardwareStatus
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonButton
import com.example.ui.components.PulsingStatusDot
import com.example.ui.theme.*

@Composable
fun HardwareLifespanScreen(
    status: HardwareStatus,
    onToggleCap: () -> Unit,
    onSetCap: (Int) -> Unit,
    onApplyCoreAffinity: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp)
    ) {
        // Module Overview Banner
        item {
            GlassCard(
                borderColor = NeonCyan,
                backgroundColor = Color(0xCC071120)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Lifespan",
                        tint = NeonCyan,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "الموديول 1: الخلود والتحكم بالعتاد (8 Years Lifespan)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "حماية اللوحة الأم ومعالج AirTab T5000 من الدمار الحراري ليدوم 8 سنوات",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Feature 1: The 80% CPU & GPU Cap
        item {
            GlassCard(borderColor = if (status.isCapEnabled) NeonCyan else Color.Gray) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "1. تقييد المعالج بـ 80% (The 80% Cap)",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            if (status.isCapEnabled) {
                                PulsingStatusDot(color = NeonGreen)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "تعديل scaling_max_freq لمنع المعالج و GPU من تجاوز 80% من الطاقة لتفادي الاحتراق.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = status.isCapEnabled,
                        onCheckedChange = { onToggleCap() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = CosmicSurfaceVariant
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "الحد الأقصى للتردد: ${status.cpuCapPercent}% (${(status.maxCpuMhz * (status.cpuCapPercent / 100.0)).toInt()} MHz)",
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Slider(
                    value = status.cpuCapPercent.toFloat(),
                    onValueChange = { onSetCap(it.toInt()) },
                    valueRange = 60f..100f,
                    steps = 7,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonBlue,
                        inactiveTrackColor = CosmicSurfaceVariant
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "60% (أقصى برودة)", color = TextSecondary, fontSize = 10.sp)
                    Text(text = "80% (النسبة الذهبية المقترحة)", color = NeonGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(text = "100% (خطر حراري)", color = NeonRed, fontSize = 10.sp)
                }
            }
        }

        // Feature 2: Core Controller (Big Core & Little Core)
        item {
            GlassCard(borderColor = NeonBlue) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "2. التحكم في الأنوية (Core Controller)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "تخصيص الأنوية الكبرى (Big Cores) للعبة والأنوية الصغرى للنظام",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    NeonButton(
                        text = "تثبيت الأنوية",
                        onClick = onApplyCoreAffinity,
                        modifier = Modifier.height(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Cores Visualizer Grid
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val rows = status.cores.chunked(2)
                    rows.forEach { rowCores ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowCores.forEach { core ->
                                val isBig = core.id >= 4
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isBig) Color(0x330066FF) else Color(0x22131D33))
                                        .border(
                                            1.dp,
                                            if (isBig) NeonCyan.copy(alpha = 0.6f) else Color(0x444A5568),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(8.dp)
                                ) {
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "Core #${core.id}",
                                                color = if (isBig) NeonCyan else TextPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                            Text(
                                                text = if (isBig) "BIG CORE" else "LITTLE",
                                                color = if (isBig) NeonGreen else TextSecondary,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "${core.currentFreqMhz} MHz | ${core.usagePercent}%",
                                            color = TextSecondary,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Feature 3: Battery Guardian & Bypass Charging
        item {
            GlassCard(borderColor = NeonYellow) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BatteryChargingFull,
                        contentDescription = "Battery Guardian",
                        tint = NeonYellow,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "3. حارس البطارية ومنع الانتفاخ",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "تنبيه الشحن عند 80%، وتفعيل محاكاة Bypass Charging لمراقبة الفولتية",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "مستوى البطارية", color = TextSecondary, fontSize = 11.sp)
                        Text(text = "${status.batteryLevel}%", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Column {
                        Text(text = "الفولتية اللحظية", color = TextSecondary, fontSize = 11.sp)
                        Text(text = "${status.batteryVoltageMv} mV", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Column {
                        Text(text = "حالة Bypass", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = if (status.isBypassChargingActive) "نشط (طاقة مباشرة)" else "حماية معتدلة",
                            color = if (status.isBypassChargingActive) NeonGreen else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Feature 4: Predictive Cooling at 39°C
        item {
            GlassCard(borderColor = if (status.batteryTempC >= 39f) NeonRed else NeonPurple) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AcUnit,
                        contentDescription = "Cooling",
                        tint = if (status.batteryTempC >= 39f) NeonRed else NeonCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "4. التبريد التنبؤي (Predictive Cooling @ 39°C)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "خفض السطوع والترددات فوراً قبل وصول الحرارة إلى مرحلة الخطر (39°C)",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الحرارة الحالية: ${status.batteryTempC}°C",
                        color = if (status.batteryTempC >= 39f) NeonRed else NeonGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    val statusLabel = if (status.batteryTempC >= 39f) "⚠️ تبريد طارئ نشط" else "آمن ومستقر"
                    val statusColor = if (status.batteryTempC >= 39f) NeonRed else NeonGreen

                    Text(
                        text = statusLabel,
                        color = statusColor,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
