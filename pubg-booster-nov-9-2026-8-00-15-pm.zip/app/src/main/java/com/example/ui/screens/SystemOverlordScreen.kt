package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HudOverlayConfig
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonButton
import com.example.ui.components.PulsingStatusDot
import com.example.ui.theme.*

@Composable
fun SystemOverlordScreen(
    hudConfig: HudOverlayConfig,
    onToggleHud: (Boolean) -> Unit,
    isWatchdogActive: Boolean,
    onToggleWatchdog: (Boolean) -> Unit,
    isGhostMode: Boolean,
    onToggleGhostMode: () -> Unit,
    onPanicReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp)
    ) {
        // Module Header
        item {
            GlassCard(borderColor = NeonCyan, backgroundColor = Color(0xCC071120)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Overlord",
                        tint = NeonCyan,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "الموديول 6: السيطرة المطلقة (System Overlord)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "اللوحة العائمة، حارس الخلود الدائم، وضع الشبح، وزر الطوارئ الشامل",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Overlay Permission Banner if needed
        item {
            if (!Settings.canDrawOverlays(context)) {
                GlassCard(borderColor = NeonYellow) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "⚠️ إذن الظهور فوق التطبيقات (Overlay Permission)",
                                color = NeonYellow,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "مطلوب لعرض شاشة الـ HUD وشبكة التصويب فوق لعبة ببجي",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        NeonButton(
                            text = "منح الإذن",
                            onClick = {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            },
                            color = NeonYellow,
                            modifier = Modifier.height(34.dp)
                        )
                    }
                }
            }
        }

        // 1. Live Floating HUD Over PUBG
        item {
            GlassCard(borderColor = if (hudConfig.isEnabled) NeonGreen else NeonCyan) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "4. اللوحة العائمة فوق اللعبة (Floating Gaming HUD)",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            if (hudConfig.isEnabled) PulsingStatusDot(color = NeonGreen)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "عرض شريط متحرك فوق اللعبة يوضح FPS، البينج (Ping)، وحرارة البطارية في الوقت الحقيقي.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = hudConfig.isEnabled,
                        onCheckedChange = { onToggleHud(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = NeonGreen)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Preview Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF030712))
                        .border(1.dp, NeonGreen.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Text(text = "FPS: 60 [STABLE]", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(text = "PING: 24ms [OPTIMAL]", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(text = "TEMP: 34.2°C [SAFE]", color = NeonYellow, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // 2. Watchdog & WakeLock (Immortal Protocol)
        item {
            GlassCard(borderColor = if (isWatchdogActive) NeonPurple else Color.Gray) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "1. حارس الخلود (Watchdog & WakeLock)",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            if (isWatchdogActive) PulsingStatusDot(color = NeonPurple)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "تثبيت عملية التطبيق في الذاكرة عبر Foreground Service و WakeLock لمنع نظام الأندرويد من إيقافه.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = isWatchdogActive,
                        onCheckedChange = { onToggleWatchdog(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = NeonPurple)
                    )
                }
            }
        }

        // 3. Ghost Mode
        item {
            GlassCard(borderColor = NeonBlue) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "2. وضع الشبح (Stealth Ghost Mode)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "تمويه واجهة التطبيق إلى آلة حاسبة إلكترونية متطورة. يتم الدخول بكود سري [ 7777= ].",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    NeonButton(
                        text = "دخول الشبح 👻",
                        onClick = onToggleGhostMode,
                        color = NeonBlue,
                        modifier = Modifier.height(36.dp)
                    )
                }
            }
        }

        // 4. Panic Reset (Emergency Button)
        item {
            GlassCard(
                borderColor = NeonRed,
                backgroundColor = Color(0x33FF2A5F)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Panic Reset",
                        tint = NeonRed,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "3. زر الطوارئ الشامل (Panic Reset)",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "إلغاء فوري لكل النوافذ العائمة، وإعادة الترددات والإنترنت والدقة إلى وضع المصنع بضغطة واحدة.",
                            color = Color(0xFFFFD4DE),
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                NeonButton(
                    text = "🚨 تنفيذ زر الطوارئ الفوري (PANIC RESET)",
                    onClick = onPanicReset,
                    color = NeonRed,
                    isFilled = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
