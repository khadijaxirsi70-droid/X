package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NetworkState
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonButton
import com.example.ui.components.PulsingStatusDot
import com.example.ui.theme.*

@Composable
fun QuantumNetworkScreen(
    state: NetworkState,
    onRunBenchmark: () -> Unit,
    onToggleWifiLock: () -> Unit,
    onToggleKillSwitch: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp)
    ) {
        // Module Title
        item {
            GlassCard(borderColor = NeonCyan, backgroundColor = Color(0xCC071120)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = "Quantum Network",
                        tint = NeonCyan,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "الموديول 3: الشبكة الكمية (Quantum Network - 25ms)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "تصفير تأخير الحزم (Jitter) وتثبيت مسار البينج على 25ms",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Live Quantum Ping & Route Stability
        item {
            GlassCard(borderColor = NeonGreen) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "4. متوقع البينج ومحلل استقرار المسار",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "تحليل حزم RTT السابقة واختيار مسار غير مزدحم لخوادم PUBG",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    PulsingStatusDot(color = NeonGreen)
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "البينج الفعلي (Ping)", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "${state.pingMs} ms",
                            color = if (state.pingMs <= 30) NeonGreen else NeonYellow,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp
                        )
                    }
                    Column {
                        Text(text = "التذبذب (Jitter)", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "±${state.jitterMs} ms",
                            color = NeonCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                    Column {
                        Text(text = "فقد الحزم (Loss)", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "${state.packetLossPercent}%",
                            color = NeonGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                    Column {
                        Text(text = "جودة المسار", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "${state.routeStabilityScore}%",
                            color = NeonGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                }
            }
        }

        // WiFi Power Save Lock & Kill Switch
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // WiFi Lock Card
                GlassCard(
                    borderColor = if (state.isWifiLockActive) NeonCyan else Color.Gray,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "منع خمول الواي فاي",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Switch(
                            checked = state.isWifiLockActive,
                            onCheckedChange = { onToggleWifiLock() },
                            colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                        )
                    }
                    Text(
                        text = "تعطيل power_save للواي فاي لإلغاء أي تأخير في إرسال الحزم.",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }

                // Kill Switch Card
                GlassCard(
                    borderColor = if (state.isKillSwitchActive) NeonRed else Color.Gray,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "قاطع الشبكة",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Switch(
                            checked = state.isKillSwitchActive,
                            onCheckedChange = { onToggleKillSwitch() },
                            colors = SwitchDefaults.colors(checkedThumbColor = NeonRed)
                        )
                    }
                    Text(
                        text = "حظر سحب الإنترنت عن كل التطبيقات في الخلفية وتكريسه لببجي فقط.",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // DNS Benchmark (6 Servers)
        item {
            GlassCard(borderColor = NeonBlue) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "1. اختبار الـ DNS ومقارنة 6 خوادم",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "فحص حقيقي لسرعة الاستجابة وتطبيق الخادم الأقل زمناً",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    NeonButton(
                        text = "فحص الخوادم ⚡",
                        onClick = onRunBenchmark,
                        color = NeonCyan,
                        modifier = Modifier.height(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.benchmarks.forEach { dns ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (dns.isBest) Color(0x3300FF88) else Color(0x1A131D33))
                                .border(
                                    1.dp,
                                    if (dns.isBest) NeonGreen else Color(0x334A5568),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = dns.name,
                                        color = if (dns.isBest) NeonGreen else TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    if (dns.isBest) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "الأسرع لـ PUBG ★",
                                            color = NeonGreen,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                                Text(
                                    text = "${dns.primaryIp} | ${dns.secondaryIp}",
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            }

                            Text(
                                text = if (dns.latencyMs > 0) "${dns.latencyMs} ms" else "جاهز للفحص",
                                color = if (dns.isBest) NeonGreen else NeonCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
