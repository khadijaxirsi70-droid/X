package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00F0FF)
val NeonBlue = Color(0xFF0066FF)
val CosmicDark = Color(0xFF050811)
val CosmicSurface = Color(0xFF0B1220)
val CosmicSurfaceVariant = Color(0xFF131D33)
val GlassCardBg = Color(0xD90A1124)
val GlassBorder = Color(0x6600F0FF)

val NeonGreen = Color(0xFF00FF88)
val NeonYellow = Color(0xFFFFD600)
val NeonRed = Color(0xFFFF2A5F)
val NeonPurple = Color(0xFF9D4EDD)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextCyan = Color(0xFF58A6FF)
