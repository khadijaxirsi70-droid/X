package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CrosshairConfig
import com.example.model.CrosshairStyle
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonButton
import com.example.ui.theme.*

@Composable
fun GamerEdgeScreen(
    sensitivities: Map<String, Int>,
    onCalculateSensitivity: (Float, Int, Boolean) -> Unit,
    zonePhase: Int,
    zoneTimeSeconds: Int,
    isZoneTimerRunning: Boolean,
    onToggleZoneTimer: () -> Unit,
    onAdvanceZonePhase: () -> Unit,
    onResetZoneTimer: () -> Unit,
    audioPreset: String,
    onSelectAudioPreset: (String) -> Unit,
    eyeFilterActive: Boolean,
    onToggleEyeFilter: (Boolean) -> Unit,
    crosshairConfig: CrosshairConfig,
    onToggleCrosshair: (Boolean, CrosshairStyle?, String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var screenSizeInput by remember { mutableStateOf("10.5") }
    var refreshRateInput by remember { mutableIntStateOf(60) }
    var gyroToggle by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp)
    ) {
        // Module Title
        item {
            GlassCard(borderColor = NeonCyan, backgroundColor = Color(0xCC071120)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SportsEsports,
                        contentDescription = "Gamer's Edge",
                        tint = NeonCyan,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "الموديول 5: ميزات اللاعب المحترف (Gamer's Edge Overlays)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "شبكة تصويب نيون، مؤقت الدائرة، صوت 3D للخطوات، وحساسية المحترفين",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // 1. Crosshair Overlay (Neon Reticle)
        item {
            GlassCard(borderColor = if (crosshairConfig.isEnabled) NeonCyan else Color.Gray) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "5. شبكة التصويب النيونية (Crosshair Overlay)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "رسم نقطة نيونية ثابتة في منتصف الشاشة لمساعدتك على الهيب فاير وقنص الرؤوس بدقة",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = crosshairConfig.isEnabled,
                        onCheckedChange = { onToggleCrosshair(it, null, null) },
                        colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Styles Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val styles = listOf(
                        CrosshairStyle.NEON_DOT to "نقطة نيون",
                        CrosshairStyle.CYBER_CROSS to "صليب سايبر",
                        CrosshairStyle.CIRCLE_DOT to "دائرة وقناص",
                        CrosshairStyle.DRAGON_EYE to "عين التنين"
                    )

                    styles.forEach { (style, name) ->
                        val isSelected = crosshairConfig.style == style
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0x3300F0FF) else Color(0x1A131D33))
                                .border(1.dp, if (isSelected) NeonCyan else Color(0x334A5568), RoundedCornerShape(8.dp))
                                .clickable { onToggleCrosshair(crosshairConfig.isEnabled, style, null) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = name,
                                color = if (isSelected) NeonCyan else TextSecondary,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Color Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "لون الشبكة:", color = TextSecondary, fontSize = 11.sp)
                    val colors = listOf("#00F0FF", "#00FF88", "#FFD600", "#FF2A5F", "#9D4EDD")
                    colors.forEach { hex ->
                        val color = Color(android.graphics.Color.parseColor(hex))
                        val isSelected = crosshairConfig.colorHex.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(if (isSelected) 2.dp else 0.dp, Color.White, CircleShape)
                                .clickable { onToggleCrosshair(crosshairConfig.isEnabled, null, hex) }
                        )
                    }
                }
            }
        }

        // 2. Blue Zone Countdown Timer
        item {
            GlassCard(borderColor = NeonBlue) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "2. مؤقت المنطقة الزرقاء (Blue Zone Timer)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "العد التنازلي الدقيق لتحرك الزون ومقدار الضرر (DPS) لكل مرحلة",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Text(
                        text = "المرحلة: $zonePhase / 8",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Timer Display
                val minutes = zoneTimeSeconds / 60
                val seconds = zoneTimeSeconds % 60
                val formattedTime = "%02d:%02d".format(minutes, seconds)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "الوقت المتبقي حتى الزون", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = formattedTime,
                            color = if (zoneTimeSeconds <= 30) NeonRed else NeonGreen,
                            fontWeight = FontWeight.Black,
                            fontSize = 32.sp
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NeonButton(
                            text = if (isZoneTimerRunning) "إيقاف مؤقت" else "بدء الزون ⏱️",
                            onClick = onToggleZoneTimer,
                            color = if (isZoneTimerRunning) NeonYellow else NeonGreen,
                            modifier = Modifier.height(40.dp)
                        )
                        NeonButton(
                            text = "التالي >>",
                            onClick = onAdvanceZonePhase,
                            color = NeonCyan,
                            modifier = Modifier.height(40.dp)
                        )
                    }
                }
            }
        }

        // 3. Pro Sensitivity Generator
        item {
            GlassCard(borderColor = NeonYellow) {
                Text(
                    text = "1. مولد الحساسية للمحترفين (Pro Sensitivity Generator)",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "حساب دقيق لنسب الحساسية بناءً على حجم شاشة التابلت ومعدل الإطارات",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = screenSizeInput,
                        onValueChange = { screenSizeInput = it },
                        label = { Text("حجم الشاشة (إنش)") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = Color(0x664A5568)
                        )
                    )

                    OutlinedTextField(
                        value = "$refreshRateInput Hz",
                        onValueChange = { },
                        readOnly = true,
                        label = { Text("التردد") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = Color(0x664A5568)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                NeonButton(
                    text = "توليد كود الحساسية الذكي ⚡",
                    onClick = {
                        val size = screenSizeInput.toFloatOrNull() ?: 10.5f
                        onCalculateSensitivity(size, refreshRateInput, gyroToggle)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    color = NeonCyan
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Sensitivity Table
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    sensitivities.forEach { (scope, value) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0x1A131D33))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = scope, color = TextPrimary, fontSize = 11.sp)
                            Text(text = "$value%", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // 4. 3D Spatial Audio & Footstep Enhancer
        item {
            GlassCard(borderColor = NeonPurple) {
                Text(
                    text = "3. محسن الصوت 3D وتمييز الخطوات (Footstep Spatializer)",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "رفع ترددات 1kHz-4kHz لسماع حركات الأقدام وتبديل أسلحة الأعداء قبل اقترابهم",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                val presets = listOf(
                    "Footstep Clarity (High-Mid 2.4kHz Boost)",
                    "Gunshot Direction Spatializer",
                    "Balanced Competitive Tournament Mode",
                    "Pure Audio Direct"
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    presets.forEach { preset ->
                        val isSelected = audioPreset == preset
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0x339D4EDD) else Color(0x1A131D33))
                                .border(1.dp, if (isSelected) NeonPurple else Color(0x334A5568), RoundedCornerShape(8.dp))
                                .clickable { onSelectAudioPreset(preset) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { onSelectAudioPreset(preset) },
                                colors = RadioButtonDefaults.colors(selectedColor = NeonPurple)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = preset,
                                color = if (isSelected) NeonCyan else TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // 5. Eye Defense Filter & RTMP Stream Helper
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Eye Filter
                GlassCard(
                    borderColor = if (eyeFilterActive) NeonYellow else Color.Gray,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "فلتر حماية العين", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Switch(
                            checked = eyeFilterActive,
                            onCheckedChange = { onToggleEyeFilter(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = NeonYellow)
                        )
                    }
                    Text(
                        text = "طبقة كهرمانية لحجب الضوء الأزرق المجهد للعين مع الحفاظ على وضوح الأعداء.",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }

                // RTMP Live Stream
                GlassCard(borderColor = NeonBlue, modifier = Modifier.weight(1f)) {
                    Text(text = "بث RTMP المباشر", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "دعم بث TikTok & YouTube بدقة 720p 60fps بمعدل 4500 Kbps لتابلت AirTab.",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
