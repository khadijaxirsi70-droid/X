package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.model.CrosshairStyle

class BoosterOverlayService : Service() {
    private val TAG = "BoosterOverlayService"
    private var windowManager: WindowManager? = null

    // Overlay Views
    private var hudView: View? = null
    private var crosshairView: View? = null
    private var eyeFilterView: View? = null

    companion object {
        const val CHANNEL_ID = "booster_overlay_channel"
        const val ACTION_START_HUD = "ACTION_START_HUD"
        const val ACTION_STOP_HUD = "ACTION_STOP_HUD"
        const val ACTION_UPDATE_CROSSHAIR = "ACTION_UPDATE_CROSSHAIR"
        const val ACTION_TOGGLE_EYE_FILTER = "ACTION_TOGGLE_EYE_FILTER"
        const val ACTION_PANIC_RESET = "ACTION_PANIC_RESET"

        var isHudActive = false
        var isCrosshairActive = false
        var isEyeFilterActive = false

        var crosshairStyle = CrosshairStyle.NEON_DOT
        var crosshairColor = 0xFF00F0FF.toInt()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1001, buildNotification())

        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "Cannot draw overlay: permission not granted yet.")
            return START_NOT_STICKY
        }

        when (intent?.action) {
            ACTION_START_HUD -> showHudOverlay()
            ACTION_STOP_HUD -> removeHudOverlay()
            ACTION_UPDATE_CROSSHAIR -> {
                val enable = intent.getBooleanExtra("ENABLE", false)
                if (enable) showCrosshairOverlay() else removeCrosshairOverlay()
            }
            ACTION_TOGGLE_EYE_FILTER -> {
                val enable = intent.getBooleanExtra("ENABLE", false)
                if (enable) showEyeFilterOverlay() else removeEyeFilterOverlay()
            }
            ACTION_PANIC_RESET -> {
                panicResetAll()
                stopSelf()
            }
        }

        return START_STICKY
    }

    private fun showHudOverlay() {
        if (hudView != null) return
        try {
            val layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 60
                y = 120
            }

            val hudLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(24, 12, 24, 12)
                setBackgroundColor(0xD90A1124.toInt())

                val fpsText = TextView(context).apply {
                    text = "FPS: 60"
                    setTextColor(0xFF00FF88.toInt())
                    textSize = 12f
                    setPadding(0, 0, 16, 0)
                }
                val pingText = TextView(context).apply {
                    text = "PING: 24ms"
                    setTextColor(0xFF00F0FF.toInt())
                    textSize = 12f
                    setPadding(0, 0, 16, 0)
                }
                val tempText = TextView(context).apply {
                    text = "34°C"
                    setTextColor(0xFFFFD600.toInt())
                    textSize = 12f
                }

                addView(fpsText)
                addView(pingText)
                addView(tempText)
            }

            // Make draggable
            var initialX = 0
            var initialY = 0
            var initialTouchX = 0f
            var initialTouchY = 0f

            hudLayout.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        layoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager?.updateViewLayout(hudLayout, layoutParams)
                        true
                    }
                    else -> false
                }
            }

            windowManager?.addView(hudLayout, layoutParams)
            hudView = hudLayout
            isHudActive = true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to attach HUD overlay: ${e.message}")
        }
    }

    private fun removeHudOverlay() {
        try {
            hudView?.let { windowManager?.removeView(it) }
            hudView = null
            isHudActive = false
        } catch (e: Exception) {
            Log.w(TAG, "Error removing HUD overlay: ${e.message}")
        }
    }

    private fun showCrosshairOverlay() {
        if (crosshairView != null) removeCrosshairOverlay()
        try {
            val layoutParams = WindowManager.LayoutParams(
                120,
                120,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
            }

            val frame = FrameLayout(this)
            val centerDot = View(this).apply {
                setBackgroundColor(crosshairColor)
            }
            frame.addView(centerDot, FrameLayout.LayoutParams(16, 16, Gravity.CENTER))

            windowManager?.addView(frame, layoutParams)
            crosshairView = frame
            isCrosshairActive = true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to attach crosshair overlay: ${e.message}")
        }
    }

    private fun removeCrosshairOverlay() {
        try {
            crosshairView?.let { windowManager?.removeView(it) }
            crosshairView = null
            isCrosshairActive = false
        } catch (e: Exception) {
            Log.w(TAG, "Error removing crosshair: ${e.message}")
        }
    }

    private fun showEyeFilterOverlay() {
        if (eyeFilterView != null) return
        try {
            val layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )

            val filter = View(this).apply {
                // Warm amber anti-blue light tint (approx 12% alpha)
                setBackgroundColor(0x22FFA500.toInt())
            }

            windowManager?.addView(filter, layoutParams)
            eyeFilterView = filter
            isEyeFilterActive = true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to attach eye filter overlay: ${e.message}")
        }
    }

    private fun removeEyeFilterOverlay() {
        try {
            eyeFilterView?.let { windowManager?.removeView(it) }
            eyeFilterView = null
            isEyeFilterActive = false
        } catch (e: Exception) {
            Log.w(TAG, "Error removing eye filter: ${e.message}")
        }
    }

    fun panicResetAll() {
        removeHudOverlay()
        removeCrosshairOverlay()
        removeEyeFilterOverlay()
    }

    override fun onDestroy() {
        super.onDestroy()
        panicResetAll()
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("PUBG Booster: Absolute HUD Active")
            .setContentText("Hardware Overlord Overlay & Crosshair online")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Booster Overlays",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live gaming HUD and gaming overlays"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
