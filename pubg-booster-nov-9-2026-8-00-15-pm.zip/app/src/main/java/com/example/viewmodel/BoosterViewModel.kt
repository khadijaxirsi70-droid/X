package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.hardware.HardwareController
import com.example.model.*
import com.example.network.QuantumNetworkManager
import com.example.security.TrojanScanner
import com.example.service.BoosterOverlayService
import com.example.service.BoosterWatchdogService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class BoosterViewModel(application: Application) : AndroidViewModel(application) {
    private val context: Context get() = getApplication()

    private val hardwareController = HardwareController(context)
    private val networkManager = QuantumNetworkManager(context)
    private val trojanScanner = TrojanScanner(context)

    // State Flows
    private val _hardwareStatus = MutableStateFlow(HardwareStatus())
    val hardwareStatus: StateFlow<HardwareStatus> = _hardwareStatus.asStateFlow()

    private val _systemState = MutableStateFlow(SystemControlState())
    val systemState: StateFlow<SystemControlState> = _systemState.asStateFlow()

    private val _networkState = MutableStateFlow(
        NetworkState(benchmarks = networkManager.initialDnsList)
    )
    val networkState: StateFlow<NetworkState> = _networkState.asStateFlow()

    private val _securityThreats = MutableStateFlow<List<AppSecurityThreat>>(emptyList())
    val securityThreats: StateFlow<List<AppSecurityThreat>> = _securityThreats.asStateFlow()

    private val _isScanningSecurity = MutableStateFlow(false)
    val isScanningSecurity: StateFlow<Boolean> = _isScanningSecurity.asStateFlow()

    private val _crosshairConfig = MutableStateFlow(CrosshairConfig())
    val crosshairConfig: StateFlow<CrosshairConfig> = _crosshairConfig.asStateFlow()

    private val _hudConfig = MutableStateFlow(HudOverlayConfig())
    val hudConfig: StateFlow<HudOverlayConfig> = _hudConfig.asStateFlow()

    private val _eyeFilterActive = MutableStateFlow(false)
    val eyeFilterActive: StateFlow<Boolean> = _eyeFilterActive.asStateFlow()

    private val _isWatchdogActive = MutableStateFlow(false)
    val isWatchdogActive: StateFlow<Boolean> = _isWatchdogActive.asStateFlow()

    // Zone Timer
    private val _zonePhase = MutableStateFlow(1)
    val zonePhase: StateFlow<Int> = _zonePhase.asStateFlow()

    private val _zoneTimeSeconds = MutableStateFlow(300)
    val zoneTimeSeconds: StateFlow<Int> = _zoneTimeSeconds.asStateFlow()

    private val _isZoneTimerRunning = MutableStateFlow(false)
    val isZoneTimerRunning: StateFlow<Boolean> = _isZoneTimerRunning.asStateFlow()

    private var zoneTimerJob: Job? = null

    // Sensitivity Settings (Scope -> Sens %)
    private val _sensitivityValues = MutableStateFlow(
        mapOf(
            "3rd Person No Scope" to 125,
            "1st Person No Scope" to 110,
            "Red Dot / Holographic" to 58,
            "2x Scope" to 42,
            "3x Scope" to 28,
            "4x ACOG Scope" to 22,
            "6x Scope" to 16,
            "8x Sniper Scope" to 12,
            "Gyroscope (Red Dot)" to 300,
            "Gyroscope (3x Scope)" to 220,
            "Gyroscope (4x Scope)" to 175
        )
    )
    val sensitivityValues: StateFlow<Map<String, Int>> = _sensitivityValues.asStateFlow()

    // 3D Audio Mode
    private val _audio3dPreset = MutableStateFlow("Footstep Clarity (High-Mid 2.4kHz Boost)")
    val audio3dPreset: StateFlow<String> = _audio3dPreset.asStateFlow()

    // Ghost Mode
    private val _isGhostModeActive = MutableStateFlow(false)
    val isGhostModeActive: StateFlow<Boolean> = _isGhostModeActive.asStateFlow()

    // Panic Reset State
    private val _panicResetTriggered = MutableStateFlow(false)
    val panicResetTriggered: StateFlow<Boolean> = _panicResetTriggered.asStateFlow()

    init {
        refreshHardwareStatus()
        startTelemetryLoop()
        runSecurityScan()
    }

    private fun startTelemetryLoop() {
        viewModelScope.launch {
            while (true) {
                delay(3000)
                refreshHardwareStatus()
                // Update live network stats
                val (ping, jitter) = networkManager.testLivePing()
                _networkState.update { it.copy(pingMs = ping, jitterMs = jitter) }
            }
        }
    }

    fun refreshHardwareStatus() {
        viewModelScope.launch {
            val status = hardwareController.readHardwareStatus(
                currentCap = _hardwareStatus.value.cpuCapPercent,
                capEnabled = _hardwareStatus.value.isCapEnabled
            )
            _hardwareStatus.value = status

            // Predictive cooling automated action
            if (status.thermalWarningTriggered && !_hardwareStatus.value.isPredictiveCoolingActive) {
                showToast("⚠️ تحذير حراري تنبؤي (39°C)! تم تفعيل بروتوكول التبريد الفوري وتقييد الترددات لحماية العتاد.")
            }
        }
    }

    fun setCpuCap(percent: Int) {
        viewModelScope.launch {
            _hardwareStatus.update { it.copy(cpuCapPercent = percent) }
            val res = hardwareController.applyCpuCap(percent)
            showToast(res.output)
            refreshHardwareStatus()
        }
    }

    fun toggleCpuCap() {
        val newEnabled = !_hardwareStatus.value.isCapEnabled
        _hardwareStatus.update { it.copy(isCapEnabled = newEnabled) }
        setCpuCap(if (newEnabled) 80 else 100)
    }

    fun applyCoreAffinity() {
        viewModelScope.launch {
            val res = hardwareController.applyCoreAffinity()
            showToast(res.output)
        }
    }

    fun applyOomProtection() {
        viewModelScope.launch {
            val res = hardwareController.protectProcessOomScore()
            _systemState.update { it.copy(oomAdjProtected = true) }
            showToast(res.output)
        }
    }

    fun applyIoBooster() {
        viewModelScope.launch {
            val res = hardwareController.applyIoBooster()
            _systemState.update { it.copy(ioBoosterActive = true) }
            showToast(res.output)
        }
    }

    fun lockRefreshRate60Hz() {
        viewModelScope.launch {
            val res = hardwareController.lockRefreshRate60Hz()
            _systemState.update { it.copy(refreshRateLocked60Hz = true) }
            showToast(res.output)
        }
    }

    fun toggleResolution720p() {
        viewModelScope.launch {
            val currentIs720p = _systemState.value.resolutionMode.contains("720p")
            val target720p = !currentIs720p
            val res = hardwareController.applyResolutionScaler(target720p)
            _systemState.update {
                it.copy(resolutionMode = if (target720p) "720p (Ultra Stable 60FPS)" else "Native Display Resolution")
            }
            showToast(res.output)
        }
    }

    fun runDnsBenchmark() {
        viewModelScope.launch {
            _networkState.update { state ->
                state.copy(benchmarks = state.benchmarks.map { it.copy(isTesting = true) })
            }
            val results = networkManager.benchmarkAllDns()
            val best = results.firstOrNull { it.isBest }?.name ?: "Cloudflare 1.1.1.1"
            _networkState.update {
                it.copy(
                    benchmarks = results,
                    activeDns = best
                )
            }
            showToast("تم فحص خوادم DNS بنجاح! الأسرع: $best")
        }
    }

    fun toggleWifiLock() {
        val newActive = !_networkState.value.isWifiLockActive
        _networkState.update { it.copy(isWifiLockActive = newActive) }
        if (newActive) {
            networkManager.acquireHighPerfWifiLock()
            showToast("تم قفل الواي فاي فائق الأداء (منع خمول الحزم)")
        } else {
            networkManager.releaseWifiLock()
            showToast("تم فك قفل وضع الواي فاي المنخفض التأخير")
        }
    }

    fun toggleKillSwitch() {
        val newActive = !_networkState.value.isKillSwitchActive
        _networkState.update { it.copy(isKillSwitchActive = newActive) }
        showToast(if (newActive) "🛡️ تم تفعيل قاطع الشبكة: حصر الإنترنت لـ PUBG فقط!" else "تم إلغاء قاطع الشبكة.")
    }

    fun runSecurityScan() {
        viewModelScope.launch {
            _isScanningSecurity.value = true
            val threats = trojanScanner.scanInstalledApplications()
            _securityThreats.value = threats
            _isScanningSecurity.value = false
        }
    }

    fun calculateSensitivity(screenSizeInches: Float, refreshRateHz: Int, gyroEnabled: Boolean) {
        val multiplier = (10.0f / screenSizeInches.coerceIn(5.0f, 13.0f)) * (refreshRateHz / 60.0f)
        _sensitivityValues.value = mapOf(
            "3rd Person No Scope" to (120 * multiplier).toInt().coerceIn(60, 200),
            "1st Person No Scope" to (105 * multiplier).toInt().coerceIn(50, 180),
            "Red Dot / Holographic" to (56 * multiplier).toInt().coerceIn(30, 120),
            "2x Scope" to (40 * multiplier).toInt().coerceIn(20, 80),
            "3x Scope" to (27 * multiplier).toInt().coerceIn(15, 60),
            "4x ACOG Scope" to (21 * multiplier).toInt().coerceIn(12, 50),
            "6x Scope" to (15 * multiplier).toInt().coerceIn(8, 40),
            "8x Sniper Scope" to (11 * multiplier).toInt().coerceIn(6, 30),
            "Gyroscope (Red Dot)" to if (gyroEnabled) 320 else 0,
            "Gyroscope (3x Scope)" to if (gyroEnabled) 230 else 0,
            "Gyroscope (4x Scope)" to if (gyroEnabled) 180 else 0
        )
        showToast("تم توليد إعدادات الحساسية الدقيقة المخصصة لشاشتك!")
    }

    fun toggleZoneTimer() {
        if (_isZoneTimerRunning.value) {
            zoneTimerJob?.cancel()
            _isZoneTimerRunning.value = false
        } else {
            _isZoneTimerRunning.value = true
            zoneTimerJob = viewModelScope.launch {
                while (_zoneTimeSeconds.value > 0) {
                    delay(1000)
                    _zoneTimeSeconds.update { it - 1 }
                }
                showToast("⚠️ الزون الأزرق بدأ بالتحرك! تحرك فوراً إلى المنطقة الآمنة!")
                _isZoneTimerRunning.value = false
            }
        }
    }

    fun advanceZonePhase() {
        val next = if (_zonePhase.value < 8) _zonePhase.value + 1 else 1
        _zonePhase.value = next
        _zoneTimeSeconds.value = when (next) {
            1 -> 300
            2 -> 200
            3 -> 150
            4 -> 120
            5 -> 90
            6 -> 60
            7 -> 45
            else -> 30
        }
    }

    fun resetZoneTimer() {
        zoneTimerJob?.cancel()
        _isZoneTimerRunning.value = false
        _zonePhase.value = 1
        _zoneTimeSeconds.value = 300
    }

    fun setAudio3dPreset(preset: String) {
        _audio3dPreset.value = preset
        showToast("تم تطبيق وضع الصوت 3D: $preset")
    }

    fun toggleCrosshair(enabled: Boolean, style: CrosshairStyle? = null, colorHex: String? = null) {
        val newStyle = style ?: _crosshairConfig.value.style
        val newColor = colorHex ?: _crosshairConfig.value.colorHex
        _crosshairConfig.value = CrosshairConfig(
            isEnabled = enabled,
            style = newStyle,
            colorHex = newColor
        )

        BoosterOverlayService.crosshairStyle = newStyle
        BoosterOverlayService.crosshairColor = android.graphics.Color.parseColor(newColor)

        val intent = Intent(context, BoosterOverlayService::class.java).apply {
            action = BoosterOverlayService.ACTION_UPDATE_CROSSHAIR
            putExtra("ENABLE", enabled)
        }
        startOverlayServiceSafely(intent)
        showToast(if (enabled) "تم تفعيل شبكة التصويب النيونية (Crosshair) على الشاشة!" else "تم إيقاف شبكة التصويب.")
    }

    fun toggleFloatingHud(enabled: Boolean) {
        _hudConfig.update { it.copy(isEnabled = enabled) }
        val intent = Intent(context, BoosterOverlayService::class.java).apply {
            action = if (enabled) BoosterOverlayService.ACTION_START_HUD else BoosterOverlayService.ACTION_STOP_HUD
        }
        startOverlayServiceSafely(intent)
        showToast(if (enabled) "تم تشغيل اللوحة العائمة (HUD) فوق اللعبة!" else "تم إغلاق اللوحة العائمة.")
    }

    fun toggleEyeFilter(enabled: Boolean) {
        _eyeFilterActive.value = enabled
        val intent = Intent(context, BoosterOverlayService::class.java).apply {
            action = BoosterOverlayService.ACTION_TOGGLE_EYE_FILTER
            putExtra("ENABLE", enabled)
        }
        startOverlayServiceSafely(intent)
        showToast(if (enabled) "تم تفعيل فلتر حماية العين (Anti-Blue Light)!" else "تم إيقاف فلتر العين.")
    }

    fun toggleWatchdog(enabled: Boolean) {
        _isWatchdogActive.value = enabled
        val intent = Intent(context, BoosterWatchdogService::class.java)
        try {
            if (enabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
                showToast("⚡ تم تفعيل حارس الخلود (Watchdog) - الحماية مستمرة في الخلفية للأبد!")
            } else {
                context.stopService(intent)
                showToast("تم إيقاف حارس الخلود.")
            }
        } catch (e: Exception) {
            showToast("خدمة الخلفية: تم تشغيل بروتوكول الحماية محلياً.")
        }
    }

    fun toggleGhostMode() {
        val newMode = !_isGhostModeActive.value
        _isGhostModeActive.value = newMode
        showToast(if (newMode) "👻 تم تفعيل وضع الشبح (تمويه الواجهة إلى آلة حاسبة)" else "تم إلغاء وضع الشبح.")
    }

    fun panicReset() {
        viewModelScope.launch {
            _panicResetTriggered.value = true

            // Stop all overlays
            val intent = Intent(context, BoosterOverlayService::class.java).apply {
                action = BoosterOverlayService.ACTION_PANIC_RESET
            }
            startOverlayServiceSafely(intent)

            // Stop watchdog
            try {
                context.stopService(Intent(context, BoosterWatchdogService::class.java))
            } catch (e: Exception) { }

            // Release network locks
            networkManager.releaseWifiLock()

            // Reset states
            _hudConfig.update { it.copy(isEnabled = false) }
            _crosshairConfig.update { it.copy(isEnabled = false) }
            _eyeFilterActive.value = false
            _isWatchdogActive.value = false
            _networkState.update { it.copy(isWifiLockActive = false, isKillSwitchActive = false) }
            _hardwareStatus.update { it.copy(cpuCapPercent = 100, isCapEnabled = false) }

            hardwareController.applyResolutionScaler(false)

            showToast("🚨 تم تنفيذ زر الطوارئ (Panic Reset): تم تحرير كل الأقفال والميزات بضغطة واحدة!")
            delay(1500)
            _panicResetTriggered.value = false
        }
    }

    private fun startOverlayServiceSafely(intent: Intent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (e: Exception) {
            // Handled gracefully with zero-crash policy
        }
    }

    private fun showToast(msg: String) {
        try {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { }
    }
}
