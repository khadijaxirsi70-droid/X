package com.example.util

import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader

data class CommandResult(
    val success: Boolean,
    val output: String,
    val error: String
)

object ShellExecutor {
    private const val TAG = "ShellExecutor"

    fun execute(command: String, asRoot: Boolean = false): CommandResult {
        return try {
            val process = if (asRoot) {
                Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            } else {
                Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            }

            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))

            val output = StringBuilder()
            val error = StringBuilder()

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.append(line).append("\n")
            }
            while (errorReader.readLine().also { line = it } != null) {
                error.append(line).append("\n")
            }

            val exitCode = process.waitFor()
            val isSuccess = exitCode == 0

            CommandResult(
                success = isSuccess,
                output = output.toString().trim(),
                error = error.toString().trim()
            )
        } catch (e: Exception) {
            Log.w(TAG, "Command execution failed (graceful zero-crash policy): ${e.message}")
            CommandResult(
                success = false,
                output = "",
                error = e.localizedMessage ?: "Execution not supported or permission denied"
            )
        }
    }

    fun isRootAvailable(): Boolean {
        return try {
            val result = execute("which su", asRoot = false)
            result.success && result.output.isNotEmpty()
        } catch (e: Exception) {
            false
        }
    }
}
